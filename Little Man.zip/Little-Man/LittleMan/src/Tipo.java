
public enum Tipo {
	VACIO(true, true), BLANDO(false, true), DURO(false, false), FUEGO(true, true);
	
	private boolean puedePosicionarseJugadorEncima;
	private boolean puedeSerExplotado;
	
	private Tipo(boolean puedePosicionarseJugadorEncima, boolean puedeSerExplotado)
	{
		this.puedePosicionarseJugadorEncima = puedePosicionarseJugadorEncima;
		this.puedeSerExplotado = puedeSerExplotado;
	}
	
	public boolean getPuedeSerExplotado()
	{
		return puedeSerExplotado;
	}
	
	public boolean getPuedePosicionarseJugadorEncima()
	{
		return puedePosicionarseJugadorEncima;
	}
	
	public boolean getJugadorChocaContraCelda()
	{
		return !getPuedePosicionarseJugadorEncima();
	}
}