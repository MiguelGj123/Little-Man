
public class Bloque extends Inamovible 
{
	private Tipo tipo;
	private int ticks;
	
	public Bloque (Tipo tipo) 
	{
		this.tipo = tipo;
	}
	
	public void romperbloque()
	{
		if (tipo != Tipo.DURO) 
		{
			this.tipo = Tipo.FUEGO;
			//System.out.println(getPosX() + " " + getPosY() + " " + ticks);
			ticks = 40;
			//System.out.println(getPosX() + " " + getPosY() + " " + ticks);
		}
	}
	
	/*
	public int getTicks()
	{
		return ticks;
	}
	*/
	
	public boolean tick()
	{
		ticks--;

		if(ticks==0) 
		{
			tipo = tipo.VACIO;
		}
		
		return ticks < 0;
	}
	
	public Tipo getTipo() {
		return tipo;
	}
	
	public void setPosX(int pPosX)
	{
		super.setPosX(pPosX);
	}
	
	public void setPosY(int pPosY)
	{
		super.setPosY(pPosY);
	}
	
	public int getPosX()
	{
		return super.getPosX();
	}
	
	public int getPosY()
	{
		return super.getPosY();
	}
	
	
}
