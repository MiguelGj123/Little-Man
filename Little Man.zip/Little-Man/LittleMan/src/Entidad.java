
public abstract class Entidad {
	
	private int posX, posY;

	public Tipo getTipo() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void setPosX(int pPosX)
	{
		posX = pPosX;
	}

	public void setPosY(int pPosY)
	{
		posY = pPosY;
	}

	public int getPosX()
	{
		return posX;
	}
	
	public int getPosY()
	{
		return posY;
	}


}
