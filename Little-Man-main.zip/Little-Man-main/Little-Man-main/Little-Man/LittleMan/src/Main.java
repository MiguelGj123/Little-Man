
public class Main {
    public static void main(String[] args)
    {

        FrameTablero frame = new FrameTablero("NEGRO");
        frame.setVisible(true);
        
        //FrameInicio frameInicio = new FrameInicio();
        //frameInicio.setVisible(true);

    }


}
