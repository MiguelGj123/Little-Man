
public abstract class EntidadInamovible extends Entidad{
	
	public EntidadInamovible(int posX, int posY) { super(posX, posY); }
	
	public int getPosX() { return super.getPosX(); }
	
	public int getPosY() { return super.getPosY(); }

}
